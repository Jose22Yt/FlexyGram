from PIL import Image
import numpy as np
from pathlib import Path
import json, shutil, hashlib, zipfile, base64, html
OUT=Path('/workspace/artifacts/FlexyGram_Duotono_Monet'); OUT.mkdir(exist_ok=True)
for sub in ['referencias','recortes_originales','android/res/drawable-nodpi','capas_tema/cuerpo','capas_tema/acento']:(OUT/sub).mkdir(parents=True,exist_ok=True)
S=Path('/workspace/generated_images')
files=['exec-bb93b508-0732-4a59-a32b-866e0de64650.png','exec-96f298ae-9adc-427e-bfc7-e5a4357ba5a4.png','exec-c3fc53e8-5724-4153-9613-d660655aa86f.png']
imgs=[Image.open(S/f).convert('RGB') for f in files]
for i,f in enumerate(files):shutil.copyfile(S/f,OUT/'referencias'/f'lamina_{i+1}.png')
# All boxes are in original, unscaled sheet pixels. Labels are outside them.
rows=[]
def row(sheet,labels,xs,y0,y1):
 for label,(x0,x1) in zip(labels,xs):rows.append((sheet,label,(x0,y0,x1,y1)))
a=[(65,201),(261,395),(447,574),(625,780),(830,965)]
row(0,['conversaciones','pantalla_principal','navegacion','ayumoments','plugins'],a,180,289)
row(0,['flexyfiles','descargas','sistema','flexystudio','acerca_de'],a,350,473)
b=[(55,267),(302,504),(567,718),(809,948)]
row(0,['interfaz_inferior','interfaz_superior','burbujas','menu_mensajes'],b,599,702)
row(0,['mensajes','menus_acciones','fotos_video_voz','stickers_emoji'],b,745,846)
row(0,['bordes_reflejos','miembros','conversiones','animaciones'],b,890,999)
c=[(112,281),(434,592),(742,899)]
row(0,['lista_titulo','mini_pildoras','avatares'],c,1127,1247)
row(0,['carpetas','elementos_visibles','apariencia'],c,1297,1403)
d=[(70,188),(264,385),(449,574),(632,769),(830,954)]
row(1,['general','red_velocidad','notificaciones','mapas','contactos'],d,170,264)
row(1,['archivo','fuentes','superficies_efectos','icono_app','privacidad'],d,303,395)
row(1,['opciones_extra','packs_iconos','emoji','nube','codigo_acceso'],d,442,538)
row(1,['barra_inferior','comportamiento','gestos','mas_opciones','editor_navegacion'],[(63,214),(279,386),(448,574),(644,761),(816,965)],642,726)
row(1,['modo_fantasma','privacidad_historias','guardado_historial','filtros_transferencia','mantenimiento'],d,818,903)
row(1,['plugins_herramientas','inteligencia_artificial','traductor','pillstack','traduccion'],[(77,185),(262,384),(444,581),(643,759),(834,954)],1006,1100)
row(1,['exportar','importar','compartir'],[(174,282),(454,568),(752,852)],1181,1262)
row(1,['volver','buscar','mas_acciones'],[(169,282),(456,560),(738,862)],1344,1427)
e=[(142,277),(440,581),(742,889)]
row(2,['ayuda','informacion','cerrar'],e,174,281)
row(2,['confirmar','restablecer','desplegar'],e,329,430)
row(2,['documento','configuracion_completa','aplicar_estilo'],e,531,641)
row(2,['guardar','enviar_copia_chat','comprimir_zip'],e,697,800)
row(2,['deshacer','rehacer','reemplazar'],e,926,1014)
row(2,['sangria','validar','vista_html'],e,1062,1173)
row(2,['borrador','carpeta_superior','abrir_archivo'],e,1274,1404)
manifest=[]; cards=[]
for sheet,name,box in rows:
 crop=imgs[sheet].crop(box); arr=np.array(crop); f=arr.astype(float)
 crop.save(OUT/'recortes_originales'/f'fg_dm_{name}.png')
 # Deterministic foreground extraction; source RGB is retained, never redrawn.
 light=f.max(axis=2); alpha=np.clip((light-75)/50,0,1)
 rgba=np.dstack([arr,np.rint(alpha*255).astype('uint8')])
 # Crop transparent margins, then center without resizing on a common 224px canvas.
 nz=np.argwhere(alpha>0)
 if len(nz)==0:raise RuntimeError(name)
 y0,x0=nz.min(axis=0); y1,x1=nz.max(axis=0)+1
 im=Image.fromarray(rgba[y0:y1,x0:x1]); canvas=Image.new('RGBA',(224,224)); pos=((224-im.width)//2,(224-im.height)//2); canvas.paste(im,pos)
 target=OUT/'android/res/drawable-nodpi'/f'fg_dm_{name}.png';canvas.save(target)
 # Semantic alpha masks for a later theme-aware drawable. These are approximations.
 accent=np.clip((f[:,:,1]-f[:,:,0]-3)/15,0,1)
 for sub,weight in [('cuerpo',1-accent),('acento',accent)]:
  mask=np.zeros_like(rgba);mask[:,:,:3]=255;mask[:,:,3]=np.rint(alpha*weight*255).astype('uint8')
  part=Image.fromarray(mask[y0:y1,x0:x1]); dst=Image.new('RGBA',(224,224));dst.paste(part,pos);dst.save(OUT/'capas_tema'/sub/f'fg_dm_{name}.png')
 # Verify unmodified crops pixel by pixel and byte-identical source RGB on visible pixels.
 assert np.array_equal(np.array(Image.open(OUT/'recortes_originales'/f'fg_dm_{name}.png')),arr)
 assert np.array_equal(np.array(im)[:,:,:3],arr[y0:y1,x0:x1])
 manifest.append(dict(nombre=name,recurso=f'fg_dm_{name}',lamina=sheet+1,recorte=list(box),referencia_pixeles_exactos=True,png_transparente_pixeles_exactos=False))
 def uri(p):return 'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode()
 cards.append(f'<article><h3>{html.escape(name.replace("_"," "))}</h3><div class="compare"><figure><img src="{uri(OUT/"recortes_originales"/f"fg_dm_{name}.png")}"><figcaption>Original sin alterar</figcaption></figure><figure><img class="converted" src="{uri(target)}"><figcaption>PNG transparente</figcaption></figure></div></article>')
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
(OUT/'VISTA_PREVIA.html').write_text('''<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>FlexyGram · revisión Duotono Monet</title><style>body{margin:24px;background:#000;color:#eee;font:15px system-ui}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:12px}article{background:#191d1b;border-radius:18px;padding:12px}h3{font-size:15px}figure{margin:8px;text-align:center}.compare{display:flex;justify-content:space-around}img{width:110px;height:110px;object-fit:contain}figcaption{font-size:11px;color:#bbb}button{padding:10px;margin:10px}body.light .converted{background:#ddd}</style><h1>FlexyGram · Duotono Monet</h1><p>85 iconos extraídos de las tres láminas aprobadas. Izquierda: píxeles originales; derecha: extracción con transparencia. Los bordes transparentes no son idénticos al original.</p><button onclick="document.body.classList.toggle('light')">Cambiar fondo de comprobación</button><main>'''+''.join(cards)+'</main></html>')
(OUT/'LEEME.txt').write_text('''FLEXYGRAM · DUOTONO MONET · PAQUETE DE REVISIÓN

85 iconos de las tres láminas. No se modificó ni compiló la aplicación.

QUÉ ES EXACTO
referencias/: las tres imágenes fuente completas, copiadas sin cambios.
recortes_originales/: recortes PNG sin reescalado ni retoques. Sus píxeles RGB son exactamente los de las láminas, incluyendo su fondo. El exportador comprueba igualdad de cada píxel.

QUÉ REQUIERE TU REVISIÓN
android/res/drawable-nodpi/: PNG RGBA de 224 x 224, transparentes, aceptados por Android como R.drawable.fg_dm_*. Conservan el RGB original dentro del recorte, sin redibujar las formas, sobre un lienzo uniforme. Se ha extraído alfa del fondo oscuro. Los bordes, huecos oscuros y la composición sobre otro fondo NO pueden garantizar igualdad píxel a píxel. El tamaño visual relativo entre símbolos conserva el de las láminas y aún requiere ajuste óptico para producción.
capas_tema/: máscaras alfa de cuerpo y acento para teñir por separado. La separación cromática es aproximada; no son vectores originales ni sustituyen los PNG de referencia.
VISTA_PREVIA.html: abrir en navegador; incluye imágenes incrustadas para comparar, incluso sin conexión.
manifest.json: nombre de recurso y coordenadas exactas de procedencia.

FORMATO E INTEGRACIÓN
Telegram Android/FlexyGram usa recursos Android PNG/WebP/drawables XML. Este ZIP NO es un paquete instalable desde Telegram ni un tema .attheme; el formato .attheme no contiene geometrías de iconos. Los PNG están listos como recursos de revisión, no aplicados a la aplicación.
Los ajustes Settings2Cell.updateForeground() y SignatureNavigationCell aplican setColorFilter() global. Integrar el duotono requiere sustituir ese tinte para estos iconos y renderizar cuerpo/acento por separado. En oscuro: cuerpo blanco; acento del tema. En claro: cuerpo oscuro; acento del tema. Las máscaras suministradas facilitan esa futura integración, pendiente de aprobación visual.
No se presentan vectores XML inventados como si fueran idénticos: las láminas generadas son imágenes raster y no contienen trazados originales.

REPRODUCCIÓN
export.py documenta la conversión. Requiere Python, Pillow y NumPy. Las rutas de origen corresponden al entorno de exportación; pueden cambiarse por las referencias incluidas. No necesita red ni credenciales.
''')
shutil.copyfile(__file__,OUT/'export.py')
checks={str(p.relative_to(OUT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in OUT.rglob('*') if p.is_file()}
(OUT/'SHA256.json').write_text(json.dumps(checks,indent=2))
z=Path('/workspace/artifacts/FlexyGram_Duotono_Monet.zip')
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as arc:
 for p in OUT.rglob('*'):
  if p.is_file():arc.write(p,str(Path(OUT.name)/p.relative_to(OUT)))
with zipfile.ZipFile(z) as arc:assert arc.testzip() is None
print(json.dumps({'icons':len(rows),'zip':str(z),'bytes':z.stat().st_size,'files':len(checks)+1,'reference_pixel_checks':'85/85 passed','android_pngs':'85 RGBA 224x224'}))

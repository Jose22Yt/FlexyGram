from pathlib import Path
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter, binary_dilation, distance_transform_edt, binary_erosion, label
import numpy as np
import shutil, json, zipfile, hashlib, base64, html
src=Path('/workspace/artifacts/FlexyGram_Duotono_Monet_Extraccion_Corregida')
out=Path('/workspace/artifacts/FlexyGram_Duotono_Monet_Bordes_Pulidos')
if out.exists():shutil.rmtree(out)
shutil.copytree(src,out)
report=[];cards=[]
for p in sorted((src/'android/res/drawable-nodpi').glob('*.png')):
 old=np.array(Image.open(p).convert('RGBA'));a=old[:,:,3].astype(float)/255
 edge=(a>0)&(a<1)
 # A small alpha-only filter confined to the contour, never the complete image.
 band=binary_dilation(edge,iterations=2)
 smooth=gaussian_filter(a,sigma=.60,mode='constant',truncate=3)
 newa=np.where(band,smooth,a)
 # Keep the original 50% coverage silhouette exactly: no erosion, dilation,
 # merging, or missing fine details. Only edge coverage transitions change.
 newa[(a>=.5)&(newa<.5)]=128/255
 newa[(a<.5)&(newa>=.5)]=127/255
 newa[np.logical_and(a==0,newa<.008)]=0
 newa[np.logical_and(a==1,newa>.992)]=1
 new=old.copy();new[:,:,3]=np.rint(newa*255).astype('uint8')
 # Replace dark-background contamination only in originally translucent edge pixels.
 # Fully opaque RGB and all protected interior pixels remain byte-identical.
 opaque=a==1
 protected=binary_erosion(opaque,iterations=2)
 _,nearest=distance_transform_edt(~protected,return_indices=True)
 edge_rgb=old[:,:,:3][tuple(nearest)].astype(float)
 # Preserve original colors wherever coverage was opaque. At partial coverage,
 # borrow local interior color, avoiding a dark fringe on light surfaces.
 translucent=band & (a>0) & ~protected
 new[:,:,:3][translucent]=np.rint(edge_rgb[translucent]).astype('uint8')
 # Newly introduced translucent edge pixels receive nearest original solid color.
 added=(a==0)&(new[:,:,3]>0)
 new[:,:,:3][added]=np.rint(edge_rgb[added]).astype('uint8')
 dest=out/'android/res/drawable-nodpi'/p.name
 Image.fromarray(new).save(dest)
 assert np.array_equal(new[:,:,:3][protected],old[:,:,:3][protected])
 assert np.array_equal(new[~band],old[~band])
 area_before=int((a>=.5).sum());area_after=int((newa>=.5).sum())
 def count_parts(binary):
  labels,n=label(binary);sizes=np.bincount(labels.ravel());return int((sizes[1:]>=4).sum())
 before_components=count_parts(a>=.5);after_components=count_parts(newa>=.5)
 assert before_components==after_components,(p.name,before_components,after_components)
 assert abs(area_before-area_after)/max(1,area_before)<.025,(p.name,area_before,area_after)
 # Update both semantic masks with the same refined alpha so they stay aligned.
 accent_old=np.array(Image.open(src/'capas_tema/acento'/p.name))[:,:,3].astype(float)
 body_old=np.array(Image.open(src/'capas_tema/cuerpo'/p.name))[:,:,3].astype(float)
 denom=np.maximum(1,accent_old+body_old);ratio=accent_old/denom
 ratio[added]=ratio[tuple(nearest)][added]
 accent_alpha=np.rint(new[:,:,3]*ratio).astype('uint8')
 for kind,alpha in [('acento',accent_alpha),('cuerpo',new[:,:,3]-accent_alpha)]:
  mask=np.full_like(new,255);mask[:,:,3]=alpha;Image.fromarray(mask).save(out/'capas_tema'/kind/p.name)
 report.append(dict(icono=p.stem,interior_rgb_inalterado=True,fuera_borde_inalterado=True,componentes_antes=before_components,componentes_despues=after_components,area_antes=area_before,area_despues=area_after,pixeles_alfa_modificados=int((new[:,:,3]!=old[:,:,3]).sum())))
 def uri(path):return 'data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode()
 cards.append(f'<article><h3>{html.escape(p.stem[6:].replace("_"," "))}</h3><div class="pair"><figure><img src="{uri(p)}"><figcaption>Antes</figcaption></figure><figure><img src="{uri(dest)}"><figcaption>Borde pulido</figcaption></figure></div></article>')
 # Keep original export for side by side review, named clearly outside Android resources.
 (out/'antes_del_pulido').mkdir(exist_ok=True);shutil.copyfile(p,out/'antes_del_pulido'/p.name)
(out/'VISTA_PREVIA.html').write_text('''<!doctype html><html lang="es"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>FlexyGram · revisión de bordes</title><style>body{background:#000;color:#eee;font:15px system-ui;margin:20px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(290px,1fr));gap:12px}article{padding:12px;background:#191d1b;border-radius:16px}h3{font-size:15px}.pair{display:flex;justify-content:space-evenly}figure{margin:4px;text-align:center}img{width:112px;height:112px;object-fit:contain;background:var(--bg,#ddd)}button{margin:6px;padding:10px}body.small img{width:66px;height:66px}figcaption{font-size:12px}</style><h1>FlexyGram · bordes pulidos</h1><p>85 iconos. Mismas formas de origen; pulido localizado del canal alfa y corrección del halo en píxeles parcialmente transparentes. Los colores interiores protegidos permanecen idénticos. También se corrigieron cajas de recorte que cortaban detalles o incluían texto.</p><button onclick="document.body.style.setProperty('--bg','#ddd')">Fondo claro</button><button onclick="document.body.style.setProperty('--bg','#191d1b')">Carbón</button><button onclick="document.body.style.setProperty('--bg','#000')">Negro</button><button onclick="document.body.classList.toggle('small')">Ver a 66 px (22 dp ×3)</button><main>'''+''.join(cards)+'</main></html>')
(out/'VALIDACION_BORDES.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
readme=out/'LEEME.txt'
readme.write_text('''REVISIÓN 2 · BORDES PULIDOS

85 iconos; se conservan lienzo, posición, colores opacos interiores, proporciones y número de componentes visibles de cada icono. No se redibujan ni se generan formas nuevas.
Se suaviza únicamente el alfa alrededor del borde (sigma 0.60 px) y se corrige la contaminación del fondo oscuro en los píxeles semitransparentes con el color interior más cercano. Los píxeles interiores protegidos (a dos píxeles del borde opaco) y los píxeles fuera de esa franja quedan idénticos a la extracción corregida. También se corrigen cajas que cortaban detalles o incluían restos de texto en el paquete anterior.
Cambiar el borde exige cambiar algunos píxeles de borde: no se afirma igualdad absoluta de todos los píxeles. Las referencias y recortes fuente siguen intactos.
VISTA_PREVIA.html compara antes/después sobre fondos claro, carbón y negro, incluyendo 66px de imagen (22dp a densidad 3x). La escala final y la integración de tintes aún requieren validación en la aplicación.
VALIDACION_BORDES.json registra las comprobaciones por icono. antes_del_pulido/ conserva los 85 PNG previos.
No se integra en la app ni se compila APK.

DOCUMENTACIÓN DEL PAQUETE ANTERIOR (PARA CONTEXTO):

'''+readme.read_text())
# Manifest accuracy: borders were refined, not a pixel-perfect original export.
m=json.loads((out/'manifest.json').read_text())
for x in m:x['borde_pulido']=True;x['rgb_interior_opaco_preservado']=True
(out/'manifest.json').write_text(json.dumps(m,ensure_ascii=False,indent=2))
shutil.copyfile(__file__,out/'pulir_bordes.py')
# Full gallery at the intended 22dp/3x sample size, on light and dark surfaces.
gallery=Image.new('RGB',(1000,9*130),'#000000'); gd=ImageDraw.Draw(gallery)
for index,png in enumerate(sorted((out/'android/res/drawable-nodpi').glob('*.png'))):
 x=(index%10)*100;y=(index//10)*130
 tile=Image.open(png).convert('RGBA').resize((66,66),Image.Resampling.LANCZOS)
 gallery.paste(Image.new('RGB',(100,100),'#dddddd'),(x,y))
 gallery.paste(tile,(x+17,y+17),tile)
 gd.text((x+3,y+103),png.stem[6:19],fill='white')
gallery.save(out/'GALERIA_66PX.png')
(out/'SHA256.json').unlink(missing_ok=True)
checks={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.rglob('*')) if p.is_file()}
(out/'SHA256.json').write_text(json.dumps(checks,indent=2))
z=out.with_suffix('.zip')
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as arc:
 for p in sorted(out.rglob('*')):
  if p.is_file():arc.write(p,str(Path(out.name)/p.relative_to(out)))
with zipfile.ZipFile(z) as arc:assert arc.testzip() is None
# Review sheet: source icon actual content at large size plus native Android sampling.
sample=['ayumoments','conversaciones','privacidad_historias','traductor','bordes_reflejos','sangria']
sheet=Image.new('RGB',(960,6*210),'#dedede');d=ImageDraw.Draw(sheet)
for i,n in enumerate(sample):
 y=i*210;d.text((10,y+5),n,fill='black')
 for j,folder in enumerate([src,out]):
  icon=Image.open(folder/'android/res/drawable-nodpi'/f'fg_dm_{n}.png').convert('RGBA')
  for k,size in enumerate([224,66]):
   tile=icon.resize((size,size),Image.Resampling.LANCZOS)
   if size==224:tile=tile.crop((25,25,199,199))
   sheet.paste(tile,(j*480+k*245,y+28),tile)
 d.text((10,y+195),'Antes: 224 px / 66 px                 Pulido: 224 px / 66 px',fill='black')
sheet.save('/workspace/artifacts/comparacion_bordes.png')
print(json.dumps({'icons':len(report),'zip':str(z),'bytes':z.stat().st_size,'protected_interior_checks':'85/85','component_count_checks':'85/85','max_area_change_percent':max(abs(r['area_despues']-r['area_antes'])/r['area_antes']*100 for r in report)}))
